package iTask;

import java.awt.Color;

import javax.swing.JPanel;

public class Fondo extends JPanel {
    //fondo de color
    public Fondo() {
        setBackground(new Color(107, 27, 62));
    }
    
    
}
